# collapsible

[![Filament Group](http://filamentgroup.com/images/fg-logo-positive-sm-crop.png) ](http://www.filamentgroup.com/)

See demo page for how-to and examples:

- http://master.origin.collapsible.fgview.com/demos/
- OR if it's a branch you want to see: http://BRANCHNAMEHERE.origin.collapsible.fgview.com/demos/

[![Build Status](https://travis-ci.org/filamentgroup/dialog.svg)](https://travis-ci.org/filamentgroup/dialog)
